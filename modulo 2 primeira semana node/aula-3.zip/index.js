const http = require("http");
const fs = require("fs");
const port = 443;

const httpserver = http.createServer((req, res) => {
  fs.readFile("site.html", (err, arq) => {
    res.writeHead(200, { "Content-Type": "text/html" });
    res.write(arq);
    return res.end();
  });
});

httpserver.listen(port, () => {
  console.log("Server Running");
});
