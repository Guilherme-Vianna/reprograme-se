const http = require('http');
const fs = require('fs');

// CHAMAR /TEXT PARA CARREGAR LER O ARQUIVO E MOSTRAR NA TELA 

http.createServer((req, res) => {
  if (req.url === '/') {
    fs.readFile('pagina.html', 'utf8', (err, html) => {
      if (err) {
        res.writeHead(500);
        res.end('Error loading pagina.html');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(html);
    });
  } else if (req.url === '/text') {
    fs.readFile('texte.txt', 'utf8', (err, text) => {
      if (err) {
        res.writeHead(500);
        res.end('Error carregando a pagina.txt');
        return;
      }
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end(text);
    });
  } else {
    res.writeHead(404);
    res.end('Not found');
  }
}).listen(3000, () => {
  console.log('Server running at http://localhost:3000/');
});
