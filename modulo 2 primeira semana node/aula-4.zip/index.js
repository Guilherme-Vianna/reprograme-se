const http = require("http");
const fs = require("fs");
const port = 443;

const httpserver = http.createServer((req, res) => {
  fs.appendFile("text.txt", "Hello World", (err) => {
    if (err) throw err;
    console.log("Arquivo Criado");
    res.end();
  });
});

httpserver.listen(port, () => {
  console.log("Server Running");
});
